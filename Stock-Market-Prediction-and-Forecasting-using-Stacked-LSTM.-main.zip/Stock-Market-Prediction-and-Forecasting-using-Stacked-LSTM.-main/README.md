# Stock-Market-Prediction-and-Forecasting-using-Stacked-LSTM.
This repository contains the file for the task that was done as part of my internship in Let's grow more with specialization - Data Science & Business Analytics.

TASK -Stock Market Prediction And Forecasting Using Stacked LSTM. Tool(s) Used - Python (Jupyter Notebook on Google Colaboratory))
