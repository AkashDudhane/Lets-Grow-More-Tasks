# Handwritten-Equation-Solver-Using-CNN

1) Run the Data_Preprocessing.py first to preprocess the data. For that you need to download the dataset (link at the bottom).
After running code a csv file will be created which will be used in the next step.

2) In this step using the csv file which was created in the last step run Train_CNN.py to train our CNN.

3) Now with the CNN_test.py you can solve the eqautions. :)


link ---> https://drive.google.com/file/d/1hMICSXwKaQ14oTdEAyOZ5hz-kOrCL6f7/view?usp=sharing
